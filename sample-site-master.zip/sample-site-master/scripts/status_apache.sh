#!/bin/bash
#getting status
service httpd status
