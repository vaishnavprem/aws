<?php 
echo "Hello World - Amrit Sharma - This is blue Green Deploymeny";

?>
